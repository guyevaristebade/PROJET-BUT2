package fr.iutfbleau.InspectorView;

/**
 * Classe qui représente un JLabel de nom
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class NameLabel extends JLabel{

    /**
     * Constructeur de la classe NameLabel
     * @param name le nom du JLabel
     * @param PhpOrNot boolean qui permet de savoir si on veut afficher du JSON ou du PHP
     */
    public NameLabel(String name, boolean PhpOrNot){
        super();
        if (PhpOrNot){
            this.setForeground(Color.WHITE);
            this.setText("["+name+"]");
            Font police = new Font("Consolas", Font.PLAIN, 16);
            this.setFont(police);
        }
        else {
            this.setForeground(Color.LIGHT_GRAY);
            this.setText("\""+name+"\"");
            Font police = new Font("Consolas", Font.PLAIN, 16);
            this.setFont(police);
        }
    }

}
