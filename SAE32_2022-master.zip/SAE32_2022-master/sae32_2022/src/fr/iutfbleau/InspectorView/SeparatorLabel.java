package fr.iutfbleau.InspectorView;

/**
 * Classe qui représente un JLabel de séparateur
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import fr.iutfbleau.InspectorModel.*;

public class SeparatorLabel extends JLabel{

    /**
     * Attribut qui représente le séparateur du JLabel
     */
    private String separator;
    /**
     * Attribut qui représente le noeud lié au séparateur
     */
    private ASTNode noeud;
    /**
     * Attribut qui représente la fenetre principale
     */
    private InspectorFrame frame;

    /**
     * Constructeur de la classe SeparatorLabel
     * @param separator le séparateur du JLabel
     */
    public SeparatorLabel(String separator){
        
        super();
        this.separator = separator;
        this.setForeground(Color.WHITE);
        this.setText(separator);
        Font police = new Font("Consolas", Font.PLAIN, 16);
        this.setFont(police);
    }

    /**
     * Deuxième constructeur de la classe SeparatorLabel, il est utilisé pour les évenements de dépli et repli
     * @param separator le séparateur du JLabel
     * @param noeud le noeud lié au séparateur 
     * @param frame la fenetre principale
     */
    public SeparatorLabel(String separator, ASTNode noeud,InspectorFrame frame){
        
        super();
        this.noeud = noeud;
        this.separator = separator;
        this.frame = frame;
        this.setForeground(Color.WHITE);
        this.setText(separator);
        Font police = new Font("Consolas", Font.PLAIN, 16);
        this.setFont(police);
    }

    /**
     * Méthode qui permet de get le noeud lié au séparateur
     * @return le noeud 
     */
    public ASTNode getNoeud(){
        return this.noeud;
    }

    /**
     * Méthode qui permet de get la fenetre principale
     * @return la fenetre principale 
     */
    public InspectorFrame getFrame(){
        return this.frame;
    }

    /**
     * Méthode qui permet de get le séparateur 
     * @return le séparateur
     */
    public String getSeparator(){
        return this.separator;
    }

}
