package fr.iutfbleau.InspectorView;

/**
 * Classe qui représente un JLabel de nombre
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class NumberLabel extends JLabel{
    
    /**
     * Constructeur de la classe NumberLabel
     * @param number le nombre du JLabel
     * @param PhpOrNot boolean qui permet de savoir si on affiche en JSON ou en PHP
     */
    public NumberLabel(String number, boolean PhpOrNot){
        super();
        if (PhpOrNot){
            this.setText(number);
            this.setForeground(Color.WHITE);
            Font police = new Font("Consolas", Font.PLAIN, 16);
            this.setFont(police);
        }
        else {
            this.setForeground(new Color(106,150,89));
            this.setText(number);
            Font police = new Font("Consolas", Font.PLAIN, 16);
            this.setFont(police);
        }
    }

}
