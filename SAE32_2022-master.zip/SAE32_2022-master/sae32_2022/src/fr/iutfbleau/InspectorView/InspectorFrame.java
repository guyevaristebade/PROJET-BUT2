package fr.iutfbleau.InspectorView;

/**
 * Classe qui représente la fenetre principale.
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import fr.iutfbleau.InspectorModel.*;
import fr.iutfbleau.InspectorControler.*;

public class InspectorFrame extends JFrame{

    /**
     * Attribut qui représente le layout du JPanel principal
     */
    private GridBagLayout layout;
    /**
     * Attributs qui représentent le gridbagconstraints du gridbaglayout
     */
    private GridBagConstraints constraints;
    private GridBagConstraints gbc;
    /**
     * Attribut qui représente la JScrollPane du JPanel principal
     */
    private JScrollPane scroll;
    /**
     * Attributs qui représentent les JPanel de la fenetre
     */
    private JPanel principal,panelUrl;
    /**
     * Attribut qui représente l'arbre de syntaxe abstraite 
     */
    private ASTTree arbre;
    /**
     * Attributs représentent les boutons tout déplier, tout plier, valider, json et php
     */
    private JButton deplier,plier,valider,json,php;
    /**
     * Attribut qui représente la barre de recherche
     */
    private JTextField champsUrl;

    /**
     * Constructeur de la classe InspectorFrame
     * @param arbre l'arbre de syntaxe abstraite à afficher
     */
    public InspectorFrame(ASTTree arbre){
        super("Inspecteur de JSON");

        this.arbre = arbre;

        this.json = new JButton("JSON");
        this.json.addActionListener(new SwitchListener(this));
        this.json.setEnabled(false);

        this.php = new JButton("PHP");
        this.php.addActionListener(new SwitchListener(this));
        this.php.setEnabled(false);

        this.deplier = new JButton("Tout déplier");
        this.deplier.addActionListener(new FoldUnfoldAll(this));

        this.plier = new JButton("Tout plier");
        this.plier.addActionListener(new FoldUnfoldAll(this));

        this.valider = new JButton("Valider");
        this.valider.addActionListener(new UrlListener(this));

        this.champsUrl = new JTextField("Veuillez donner l'url du contenu JSON à afficher");
        this.champsUrl.addMouseListener(new UrlListener(this));
        this.champsUrl.addKeyListener(new UrlListener(this));
        this.champsUrl.setFont(new Font("Consolas", Font.PLAIN, 16));

        this.panelUrl = new JPanel(new GridBagLayout());
        panelUrl.setBackground(new Color(54,57,63));

        this.gbc = new GridBagConstraints();

        addElements();
        configFrame();
    }

    /**
     * Méthode qui ajoute les composants graphiques à la fenetre principale 
     */
    public void addElements() {
        gbc.insets = new Insets(10,10,10,10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipady = 10;
        gbc.weightx = 1.0;
        gbc.weighty= 0.0;
        panelUrl.add(champsUrl,gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.ipadx = 20;        
        gbc.weightx = 0.0;
        gbc.weighty= 0.0;
        panelUrl.add(valider,gbc);

        JPanel panelBtn = new JPanel(new GridBagLayout());
        panelBtn.setBackground(new Color(54,57,63));

        gbc.insets = new Insets(10,10,10,10);
        gbc.gridx = 0;  
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.0;
        gbc.weighty= 0.0;
        panelBtn.add(this.json,gbc);

        gbc.gridx = 1;
        panelBtn.add(this.php, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.0;
        gbc.weighty= 0.0;
        panelBtn.add(this.deplier,gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.0;
        gbc.weighty= 0.0;
        panelBtn.add(this.plier,gbc);

        this.layout = new GridBagLayout();        
        this.principal = new JPanel();
        this.principal.setLayout(this.layout);
        this.principal.setBackground(new Color(54,57,63));
        this.constraints = new GridBagConstraints();
        this.constraints.fill = GridBagConstraints.BOTH;
        this.constraints.weightx = 1.0;
        this.constraints.weighty = 0.0;

        this.scroll = new JScrollPane(this.principal);
        this.scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        this.scroll.getVerticalScrollBar().setUnitIncrement(10);
        this.scroll.getHorizontalScrollBar().setUnitIncrement(10);

        this.add(panelUrl,BorderLayout.NORTH);
        this.add(this.scroll,BorderLayout.CENTER);
        this.add(panelBtn,BorderLayout.SOUTH);
    }
    
    /**
     * Méthode qui renvoie le JPanel principal (celui qui contient le code)
     * @return JPanel principal
     */
    public JPanel getPrincipalPanel(){
        return this.principal;
    }

    /**
     * Méthode qui permet de déplier tous les objets et tableaux du code JSON
     */
    public void depliTout(){
        this.arbre.deplierAll();
        this.refreshToJson();
    }

    /**
     * Méthode qui permet de replier tous les objets et tableaux du code JSON
     */
    public void pliTout(){
        this.arbre.plierAll();
        this.refreshToJson();
    }

    /**
     * Méthode qui permet de faire le refresh de la fenetre principal en JSON
     */
    public void refreshToJson(){
        JScrollBar save = this.scroll.getVerticalScrollBar();
        int saveScroll = save.getValue();
        this.remove(this.scroll);
        this.principal = new JPanel();
        this.principal.setLayout(this.layout);
        this.principal.setBackground(new Color(54,57,63));
        this.constraints = new GridBagConstraints();
        this.constraints.fill = GridBagConstraints.BOTH;
        this.constraints.weightx = 1.0;
        this.constraints.weighty = 0.0;
        this.scroll = new JScrollPane(this.principal);
        this.scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        this.scroll.getVerticalScrollBar().setUnitIncrement(10);
        this.scroll.getHorizontalScrollBar().setUnitIncrement(10);
        this.arbre.getRacine().configJSONPanel(0, this, true);
        this.constraints.gridy++;
        this.constraints.weighty = 1.0;
        this.add(this.scroll,BorderLayout.CENTER);
        this.principal.add(new JLabel(), this.constraints); 
        this.revalidate();
        this.repaint();
        this.scroll.getVerticalScrollBar().setValue(saveScroll);
    }

    /**
     * Méthode qui permet de faire le refresh de la fenetre en PHP
     */
    public void refreshToPHP(){
        JScrollBar save = this.scroll.getVerticalScrollBar();
        int saveScroll = save.getValue();
        this.remove(this.scroll);
        this.principal = new JPanel();
        this.principal.setLayout(this.layout);
        this.principal.setBackground(new Color(54,57,63));
        this.constraints = new GridBagConstraints();
        this.constraints.fill = GridBagConstraints.BOTH;
        this.constraints.weightx = 1.0;
        this.constraints.weighty = 0.0;
        this.scroll = new JScrollPane(this.principal);
        this.scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        this.scroll.getVerticalScrollBar().setUnitIncrement(10);
        this.scroll.getHorizontalScrollBar().setUnitIncrement(10);
        this.arbre.getRacine().convertToPHP(0, this, 0);
        this.constraints.gridy++;
        this.constraints.weighty = 1.0;
        this.add(this.scroll,BorderLayout.CENTER);
        this.principal.add(new JLabel(), this.constraints); 
        this.revalidate();
        this.repaint();
        this.scroll.getVerticalScrollBar().setValue(saveScroll);
    }

    /**
     * Méthode qui permet d'ajouter un JPanel au JPanel principal
     * @param pane le Jpanel à ajouter
     */
    public void addPanel(JPanel pane){
        this.constraints.gridy++;
        this.principal.add(pane,this.constraints);
    }

    /**
     * Méthode qui permet de configurer la fenetre 
     */
    public void configFrame(){
        this.setPreferredSize(new Dimension(1280,720));
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Méthode qui permet de get le gridbagConstraints 
     * @return le gridbagconstraints
     */
    public GridBagConstraints getConstraints(){
        return this.constraints;
    }

    /**
     * Méthode qui permet de get le JPanel principal
     * @return le JPanel principal
     */
    public JPanel getPrincipal(){
        return this.principal;
    }

    /**
     * Méthode qui permet de get le bouton tout déplier
     * @return le bouton déplier
     */
    public JButton getDeplier(){
        return this.deplier;
    }

    /**
     * Méthode qui permet de get le bouton tout plier
     * @return le bouton tout plier
     */
    public JButton getPlier(){
        return this.plier;
    }

    /**
     * Méthode qui permet de get la barre de recherche
     * @return la barre de recherche
     */
    public JTextField getChampsUrl(){
        return this.champsUrl;
    }

    /**
     * Méthode qui permet de set la nouvelle racine 
     * @param racine la nouvelle racine 
     */
    public void setRacine(ASTObject racine){
        this.arbre.setRacine(racine);
    }

    /**
     * Méthode qui permet de get le bouton valider
     * @return le bouton valider
     */
    public JButton getValider(){
        return this.valider;
    }

    /**
     * Méthode qui permet de get le bouton php
     * @return le bouton json
     */
    public JButton getJSONButton() {
        return this.json;
    }

    /**
     * Methode qui permet de get le bouton php
     * @return le bouton php
     */
    public JButton getPHPButton() {
        return this.php;
    }
}