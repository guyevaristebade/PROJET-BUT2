package fr.iutfbleau.InspectorMain;

/**
 * Le Main du projet
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import fr.iutfbleau.InspectorModel.*;
import fr.iutfbleau.InspectorView.*;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;

public class InspectorMain {
    public static void main(String[] args) {
        try {
            try {
                URL u = new URL(args[0]);
                try {
                    InputStream i = u.openStream();
                    ASTObject racine = new ASTObject();
                    ASTTree arbre = new ASTTree(racine);
                    arbre.parseAndFill(i);
                    System.out.print(arbre.getRacine().printConsole(0,true));
                    i.close();
                } 
                catch (IOException e) {
                    System.out.println(e);
                }
            }
            catch (MalformedURLException e) {
                System.out.println(e);
            }
        } 
        catch (ArrayIndexOutOfBoundsException e) {
            ASTObject racine = new ASTObject();
            ASTTree arbre = new ASTTree(racine);
            try {
                for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } 
            catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException | IllegalAccessException err) {
                err.printStackTrace();
            }
            new InspectorFrame(arbre);
        }
    }
}