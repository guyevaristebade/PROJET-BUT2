package fr.iutfbleau.InspectorModel;

/**
 * Classe qui représente un noeud nom, ce noeud n'a qu'un seul enfant, c'est une valeur
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import fr.iutfbleau.InspectorView.*;

public class ASTName implements ASTNode{
    
    /**
     * Attribut qui représente le nom du noeud, c'est l'information stocké
     */
    private String name;
    /**
     * Attribut qui représente la valeur associée au nom, c'est comme une liste chainée
     */
    private ASTNode valeur;

    /**
     * Constructeur de la classe ASTName
     * @param name le nom du noeud
     * @param valeur la valeur associée au nom
     */
    public ASTName(String name, ASTNode valeur){
        this.name = name;
        this.valeur = valeur;
    }

    /**
     * Méthode qui permet de get la valeur associée au nom
     * @return le noeud représentant la valeur associée au nom
     */
    public ASTNode getValeur(){
        return this.valeur;
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#printConsole(int, boolean)
     */
    public String printConsole(int tab,boolean endElement) {
        StringBuilder builder = new StringBuilder();
        builder.append("\"");
        builder.append(this.name);
        builder.append("\": ");
        if (this.valeur instanceof ASTObject || this.valeur instanceof ASTArray){
            builder.append(this.valeur.printConsole(tab+1,endElement));
        }
        else {
            builder.append(this.valeur.printConsoleForValue(endElement));
        }
        return builder.toString();
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#configJSONPanel(int, fr.iutfbleau.InspectorView.InspectorFrame, boolean)
     */
    public void configJSONPanel(int tab, InspectorFrame frame,boolean endElement){

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        NameLabel nameLabel = new NameLabel(this.name, false);
        panel.setBackground(new Color(54,57,63));
        StringBuilder builder = new StringBuilder();

        for (int i=0; i<tab;i++){
            builder.append("    ");
        }

        panel.add(new JLabel(builder.toString()));
        panel.add(nameLabel); 
        panel.add(new SeparatorLabel(":  "));

        if (this.valeur instanceof ASTObject || this.valeur instanceof ASTArray){
            this.valeur.configJSONPanelForValue(tab+1, frame, panel, endElement);
        }
        else {
            this.valeur.configJSONPanelForValue(tab, frame, panel, endElement);
        }

    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#convertToPHP(int, fr.iutfbleau.InspectorView.InspectorFrame, int)
     */
    public void convertToPHP(int tab, InspectorFrame frame, int index){
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        NameLabel nameLabel = new NameLabel(this.name, true);
        panel.setBackground(new Color(54,57,63));
        StringBuilder builder = new StringBuilder();

        for (int i=0; i<tab;i++){
            builder.append("    ");
        }

        panel.add(new JLabel(builder.toString()));
        panel.add(nameLabel); 
        panel.add(new SeparatorLabel("  =>  "));

        if (this.valeur instanceof ASTObject || this.valeur instanceof ASTArray){
            this.valeur.convertToPHPForValue(tab+1, frame, panel);
        }
        else {
            this.valeur.convertToPHPForValue(tab, frame, panel);
        }
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#setVisibility(boolean)
     */
    public void setVisibility(boolean visibility) {
        this.valeur.setVisibility(visibility);
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#setVisibilityToAll(boolean)
     */
    public void setVisibilityToAll(boolean visibility) {
        this.valeur.setVisibilityToAll(visibility); 
    }

    public void configJSONPanelForValue(int tab, InspectorFrame frame, JPanel panel,boolean endElement) {}
    
    public void convertToPHPForValue(int tab, InspectorFrame frame, JPanel panel) {}

    public boolean getVisibility() {
        return false;
    }

    public String printConsoleForValue(boolean endElement) {
        return null;
    }
}
