package fr.iutfbleau.InspectorModel;

/**
 * Classe qui permet de créer un noeud valeur qui est un boolean ou null
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.*;
import fr.iutfbleau.InspectorView.*;

public class ASTValueBoolean implements ASTNode{
    
    /**
     * Attribut qui représente la valeur du noeud
     */
    private String value;

    /**
     * Constructeur de la classe ASTValueBoolean
     * @param value la valeur du noeud
     */
    public ASTValueBoolean(String value){
        this.value = value;
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#printConsoleForValue(boolean)
     */
    public String printConsoleForValue(boolean endElement) {
        StringBuilder builder = new StringBuilder();
        builder.append(this.value);
        if (endElement){
            builder.append("\n");
        }
        else {
            builder.append(",\n");
        }
        return builder.toString();
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#printConsole(int, boolean)
     */
    public String printConsole(int tab,boolean endElement) {
        return null;
        
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#configJSONPanelForValue(int, fr.iutfbleau.InspectorView.InspectorFrame, javax.swing.JPanel, boolean)
     */
    public void configJSONPanelForValue(int tab, InspectorFrame frame, JPanel panel,boolean endElement) {
        panel.add(new OtherLabel(String.valueOf(this.value), false));
        if (endElement){
            frame.addPanel(panel);
        }
        else {
            panel.add(new SeparatorLabel(","));
            frame.addPanel(panel);
        }
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#configJSONPanel(int, fr.iutfbleau.InspectorView.InspectorFrame, boolean)
     */
    public void configJSONPanel(int tab, InspectorFrame frame,boolean endElement) {

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.setBackground(new Color(54,57,63));

        StringBuilder builder = new StringBuilder();
        for (int i=0; i<tab+1;i++){
            builder.append("    ");
        }

        panel.add(new JLabel(builder.toString()));
        panel.add(new OtherLabel(this.value, false));
        if (endElement){
            frame.addPanel(panel);
        }
        else {
            panel.add(new SeparatorLabel(","));
            frame.addPanel(panel);
        }
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#convertToPHP(int, fr.iutfbleau.InspectorView.InspectorFrame, int)
     */
    public void convertToPHP(int tab, InspectorFrame frame, int index) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.setBackground(new Color(54,57,63));

        StringBuilder builder = new StringBuilder();
        for (int i=0; i<tab+1;i++){
            builder.append("    ");
        }

        panel.add(new JLabel(builder.toString()));

        panel.add(new NameLabel(String.valueOf(index), true));
        panel.add(new SeparatorLabel("  =>  "));
        panel.add(new OtherLabel(this.value, true));

        frame.addPanel(panel);
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#convertToPHPForValue(int, fr.iutfbleau.InspectorView.InspectorFrame, javax.swing.JPanel)
     */
    public void convertToPHPForValue(int tab, InspectorFrame frame, JPanel panel) {
        panel.add(new OtherLabel(this.value, true));
        frame.addPanel(panel);
    }

    public void setVisibility(boolean visibility) {}

    public boolean getVisibility() {
        return false;
    }

    public void setVisibilityToAll(boolean visibility) {}
}
