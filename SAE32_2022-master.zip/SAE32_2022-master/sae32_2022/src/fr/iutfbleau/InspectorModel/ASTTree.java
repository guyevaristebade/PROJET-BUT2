package fr.iutfbleau.InspectorModel;

/**
 * Classe qui représente l'intégralité de l'arbre de syntaxe abstraite, c'est ici que le parsing du fichier json se fait ainsi que le remplissage de l'arbre qui se fait au fur et à mesure du parse.
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.io.IOException;
import java.io.InputStream;

public class ASTTree {

    /**
     * Attribut représentant la racine de l'arbre, c'est un ASTObject
     */
    private ASTObject racine;
    /**
     * Attributs représentant la fin d'un objet ou d'un tableau
     */
    private boolean endObj,endTab;
    
    /**
     * Ensembles d'attribut final qui représente le code ascii de plusieurs caractères, cela permet d'avoir un code plus compréhensible en remplaçant le code ascii par le nom du caractère
     */
    private final int guillement = 34;
    private final int accoladeouvrante = 123;
    private final int accoladefermante = 125;
    private final int virgule = 44;
    private final int crochetouvrant = 91;
    private final int crochetfermant = 93;
    private final int retourligne = 13;
    private final int espace = 32;
    private final int tabulation = 9;
    private final int sautligne = 10;
    private final int deuxpoints = 58;

    /**
     * Constructeur de la classe ASTTree
     * @param racine la racine de l'arbre de syntaxe abstraite
     */
    public ASTTree(ASTObject racine){
        this.racine = racine;;
        this.endObj = false;
        this.endTab = false;
    }

    /**
     * Méthode permettant de get la racine de l'arbre
     * @return la racine de l'arbre
     */
    public ASTObject getRacine(){
        return this.racine;
    }

    /**
     * Méthode permettant de set la racine de l'arbre 
     * @param racine la nouvelle racine de l'arbre
     */
    public void setRacine(ASTObject racine){
        this.racine = racine;
    }

    /**
     * Méthode permettant de déplier tous les objets et tableaux de l'arbre
     */
    public void deplierAll(){
        this.racine.setVisibilityToAll(true);
    }

    /**
     * Méthode permettant de replier tous les objets et tableaux de l'arbre 
     */
    public void plierAll(){
        this.racine.setVisibilityToAll(false);
    }

    /**
     * Méthode permettant de savoir si le caractère qu'on lit actuellement est un espace blanc ou pas
     * @param a le code ascii du caractère 
     * @return vrai si c'est un espace vide, faux si ça l'est pas
     */
    public boolean isAWhitespace(int a){
        if (a==tabulation || a==espace || a==sautligne || a==retourligne){
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Méthode qui crée un ASTObjet à partir de l'InputStream qu'on lui donne, cette méthode prend fin une fois qu'elle rencontre une accolade fermante
     * @param i l'InputStream
     * @param newobj le nouvel objet qui sera rempli au fur et à mesure de la lecture du fichier
     * @return le nouvel objet complet
     */
    public ASTObject giveMeObject(InputStream i,ASTObject newobj){
        int a;
        try {
            while ((a=i.read())!=-1) {
                if (a==accoladefermante){
                    break;
                }
                else if (!endObj){
                    if (!(this.isAWhitespace(a))){
                        if (a==guillement){
                            String nom = this.giveMeName(i);
                            while (!(a==deuxpoints)) {
                                a = i.read();
                            }
                            ASTNode newvalue = this.giveMeValue(i);
                            newobj.addElements(new ASTName(nom, newvalue));
                        }
                    }
                }
                else {
                    endObj = false;
                    break;
                }
            }
            return newobj;
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Méthode qui renvoie le nom d'une valeur, cette méthode prend fin une fois qu'on rencontre un guillement
     * @param i l'InputStream
     * @return le nom d'une valeur
     */
    public String giveMeName(InputStream i){
        int a;
        StringBuilder name = new StringBuilder();
        try {
            while ((a=i.read())!=-1) {
                if (a==guillement){
                    break;
                }
                else {
                    name.append((char)a);
                }
            }
            return name.toString();
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Méthode qui crée un noeud valeur
     * @param i l'InputStream
     * @return le nouveau noeud valeur créé
     */
    public ASTNode giveMeValue(InputStream i){
        int a;
        StringBuilder value = new StringBuilder();
        try {
            while ((a=i.read())!=-1) {
                if (a==accoladeouvrante){
                    ASTObject newobj = new ASTObject();
                    newobj = this.giveMeObject(i,newobj);
                    return newobj;
                }
                else if (a==crochetouvrant){
                    return this.giveMeArray(i);
                }
                else if (a==guillement){
                    while ((a=i.read())!=-1) {
                        if (a==guillement){
                            break;
                        }
                        // 92 c'est le code ascii du '\'
                        else if (a == 92){
                            i.read();
                        }
                        else {
                            value.append((char)a);
                        }
                    }
                    ASTValueString s = new ASTValueString(value.toString());
                    return s;
                }
                else if (!(this.isAWhitespace(a))){
                    while (a!=-1) {
                        if (a==virgule){
                            break;
                        }
                        else if (a==crochetfermant){
                            this.endTab = true;
                            break;
                        }
                        else if (a==accoladefermante){
                            this.endObj = true;
                            break;
                        }
                        else if (!(this.isAWhitespace(a))){
                            value.append((char)a);
                            a = i.read();
                        }
                        else {
                            a = i.read();
                        }
                    }
                    try {
                        ASTValueNumber n = new ASTValueNumber(Double.parseDouble(value.toString()));
                        return n;
                    } 
                    catch (NumberFormatException e) {
                        if (value.toString().equals("true")||value.toString().equals("false")||value.toString().equals("null")){
                            ASTValueBoolean b = new ASTValueBoolean(value.toString());
                            return b;
                        }
                        else {
                            ASTValueString s = new ASTValueString(value.toString());
                            return s;
                        }
                    }
                }
            }
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Méthode qui crée une nouvelle valeur et l'ajoute au tableau donné en parametre, la méthode prend fin une fois l'accolade fermante rencontrée
     * @param i l'InputStream
     * @param tab le tableau auquel on va ajouter la nouvelle valeur
     */
    public void giveMeValueForArray(InputStream i,ASTArray tab){
        int a;
        try {
            while ((a=i.read())!=-1) {
                StringBuilder value = new StringBuilder();
                if (a==accoladeouvrante){
                    ASTObject newobj = new ASTObject();
                    newobj = this.giveMeObject(i,newobj);
                    tab.addElements(newobj);
                    if (this.endTab){
                        break;
                    }
                }
                else if (a==crochetouvrant){
                    ASTArray newtab = this.giveMeArray(i);
                    tab.addElements(newtab);
                    if (this.endTab){
                        break;
                    }
                }
                else if (a==guillement){
                    while ((a=i.read())!=-1) {
                        if (a==guillement){
                            break;
                        }
                        else {
                            value.append((char)a);
                        }
                    }
                    ASTValueString s = new ASTValueString(value.toString());
                    tab.addElements(s);
                }
                else if (a==crochetfermant){
                    break;
                }
                else if (!(this.isAWhitespace(a))){
                    while (a!=-1) {
                        if (a==virgule){
                            break;
                        }
                        else if (a==crochetfermant){
                            this.endTab = true;
                            break;
                        }
                        else if (a==accoladefermante){
                            this.endObj = true;
                            break;
                        }
                        else {
                            if (this.isAWhitespace(a)){
                                a = i.read();
                            }  
                            else {
                                value.append((char)a);
                                a = i.read();
                            }
                        }
                    }
                    if (!(value.toString().equals(""))){
                        try {
                            ASTValueNumber n = new ASTValueNumber(Double.parseDouble(value.toString()));
                            tab.addElements(n);
                            if (this.endTab){
                                break;
                            }
                        } 
                        catch (NumberFormatException e) {
                            if (value.toString().equals("true")||value.toString().equals("false")||value.toString().equals("null")){
                                ASTValueBoolean b = new ASTValueBoolean(value.toString());
                                tab.addElements(b);
                                if (this.endTab){
                                    break;
                                }
                            }
                            else {
                                ASTValueString s = new ASTValueString(value.toString());
                                tab.addElements(s);
                                if (this.endTab){
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Méthode permettant de créer un ASTArray 
     * @param i l'InputStream
     * @return le nouveau tableau créé
     */
    public ASTArray giveMeArray(InputStream i){
        ASTArray tab = new ASTArray();
        this.giveMeValueForArray(i,tab);
        this.endTab = false;
        return tab;
    }

    /**
     * Methode qui parse le fichier json et remplit l'arbre de syntaxe abstraite
     * @param i l'InputStream
     */
    public void parseAndFill(InputStream i){
        int a;
        try {
            while ((a=i.read())!=-1) {
                if (a==accoladeouvrante){
                    this.racine = this.giveMeObject(i,this.racine);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
