package fr.iutfbleau.InspectorModel;

/**
 * Classe qui représente un noeud objet, ce noeud a plusieurs enfants, c'est des noms
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.FlowLayout;
import java.util.*;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import fr.iutfbleau.InspectorView.*;
import fr.iutfbleau.InspectorControler.*;

public class ASTObject implements ASTNode{
    
    /**
     * Attribut qui représente une file, elle permet de stocker les noms dans le bon ordre
     */
    private Deque<ASTName> elements;
   /**
     * Attribut qui permet de déterminer la visibilité du noeud
     */
     private boolean visibility;

    /**
     * Constructeur de la classe ASTObject
     */
    public ASTObject(){
        this.elements = new ArrayDeque<ASTName>();
        this.visibility = false;
    }

    /**
     * Methode qui permet d'ajouter un noeud nom au noeud objet
     * @param name le noeud nom
     */
    public void addElements(ASTName name){
        this.elements.add(name);
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#getVisibility()
     */
    public boolean getVisibility(){
        return this.visibility;
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#setVisibility(boolean)
     */
    public void setVisibility(boolean newVisibility){
        this.visibility = newVisibility;
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#printConsole(int, boolean)
     */
    public String printConsole(int tab,boolean endElement) {
        int index = 1;
        StringBuilder builder = new StringBuilder();

        builder.append("{\n");

        for (ASTName n : this.elements){

            for (int i = 0; i<tab+1;i++){
                builder.append("  ");
            }

            if (index == elements.size()){
                builder.append(n.printConsole(tab,true));
            }
            else {
                builder.append(n.printConsole(tab,false));
            }

            index++;
        }

        for (int i = 0; i<tab;i++){
            builder.append("  ");
        }

        if (endElement){
            builder.append("}\n");
        }
        else {
            builder.append("},\n");
        }
        return builder.toString();
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#configJSONPanel(int, fr.iutfbleau.InspectorView.InspectorFrame, boolean)
     */
    public void configJSONPanel(int tab, InspectorFrame frame, boolean endElement){

        if (this.visibility){
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i<tab; i++){
                builder.append("    ");
            }
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
            panel.setBackground(new Color(54,57,63));

            panel.add(new JLabel(builder.toString()));

            SeparatorLabel sep = new SeparatorLabel("{", this, frame);
            sep.addMouseListener(new FoldUnfoldElement(sep));
            panel.add(sep);
            frame.addPanel(panel);

            int index = 1;
            for (ASTName n : this.elements){
                if (index == this.elements.size()){
                    n.configJSONPanel(tab+1, frame,true);
                }
                else {
                    n.configJSONPanel(tab+1, frame,false);
                }
                index++;
            }

            builder = new StringBuilder();

            for (int i = 0; i<tab; i++){
                builder.append("    ");
            }

            panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
            panel.setBackground(new Color(54,57,63));

            panel.add(new JLabel(builder.toString()));
            if (endElement){
                panel.add(new SeparatorLabel("}"));
            }
            else {
                panel.add(new SeparatorLabel("},"));
            }
            frame.addPanel(panel);
        }
        else {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i<tab; i++){
                builder.append("    ");
            }
            
            JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
            panel.setBackground(new Color(54,57,63));

            panel.add(new JLabel(builder.toString()));
            if (endElement){
                SeparatorLabel sep = new SeparatorLabel("{...}", this, frame);
                sep.addMouseListener(new FoldUnfoldElement(sep));
                panel.add(sep);
            }
            else {
                SeparatorLabel sep = new SeparatorLabel("{...},", this, frame);
                sep.addMouseListener(new FoldUnfoldElement(sep));
                panel.add(sep);
            }
            frame.addPanel(panel);
        }
        
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#configJSONPanelForValue(int, fr.iutfbleau.InspectorView.InspectorFrame, javax.swing.JPanel, boolean)
     */
    public void configJSONPanelForValue(int tab, InspectorFrame frame, JPanel panel, boolean endElement) {
        if (this.visibility){
            SeparatorLabel sep = new SeparatorLabel("{", this, frame);
            sep.addMouseListener(new FoldUnfoldElement(sep));
            panel.add(sep);
            frame.addPanel(panel);


            int index = 1;
            for (ASTName n : this.elements){
                if (index == this.elements.size()){
                    n.configJSONPanel(tab+1, frame,true);
                }
                else {
                    n.configJSONPanel(tab+1, frame,false);
                }
                index++;
            }

            StringBuilder builder = new StringBuilder();

            for (int i = 0; i<tab-1; i++){
                builder.append("    ");
            }

            panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
            panel.add(new JLabel(builder.toString()));
            panel.setBackground(new Color(54,57,63));
            
            if (endElement){
                panel.add(new SeparatorLabel("}"));
            }
            else {
                panel.add(new SeparatorLabel("},"));
            }
            frame.addPanel(panel);
        }
        else {
            if (endElement){
                SeparatorLabel sep = new SeparatorLabel("{...}", this, frame);
                sep.addMouseListener(new FoldUnfoldElement(sep));
                panel.add(sep);
            }
            else {
                SeparatorLabel sep = new SeparatorLabel("{...},", this, frame);
                sep.addMouseListener(new FoldUnfoldElement(sep));
                panel.add(sep);
            }
            frame.addPanel(panel);

        }
        
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#convertToPHPForValue(int, fr.iutfbleau.InspectorView.InspectorFrame, javax.swing.JPanel)
     */
    public void convertToPHPForValue(int tab, InspectorFrame frame, JPanel panel){
        SeparatorLabel sep = new SeparatorLabel("Array", this, frame);
        panel.add(sep);
        frame.addPanel(panel);

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i<tab+1; i++){
            builder.append("    ");
        }

        panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.add(new JLabel(builder.toString()));
        panel.setBackground(new Color(54,57,63));
        sep = new SeparatorLabel("(", this, frame);
        panel.add(sep);
        frame.addPanel(panel);

        int index = 0;
        for (ASTName n : this.elements){
            n.convertToPHP(tab+2, frame, index);
            index++;
        }

        builder = new StringBuilder();
        for (int i = 0; i<tab+1; i++){
            builder.append("    ");
        }

        panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.add(new JLabel(builder.toString()));
        panel.setBackground(new Color(54,57,63));
        sep = new SeparatorLabel(")", this, frame);
        panel.add(sep);
        frame.addPanel(panel);
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#convertToPHP(int, fr.iutfbleau.InspectorView.InspectorFrame, int)
     */
    public void convertToPHP(int tab, InspectorFrame frame, int index){
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.setBackground(new Color(54,57,63));

        StringBuilder builder = new StringBuilder();
        for (int i=0; i<tab;i++){
            builder.append("    ");
        }

        panel.add(new JLabel(builder.toString()));

        panel.add(new NameLabel(String.valueOf(index), true));
        panel.add(new SeparatorLabel("  =>  Array"));
        
        frame.addPanel(panel);

        panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.setBackground(new Color(54,57,63));
        
        builder = new StringBuilder();
        for (int i=0; i<tab+1;i++){
            builder.append("    ");
        }
        panel.add(new JLabel(builder.toString()));
        SeparatorLabel sep = new SeparatorLabel("(", this, frame);
        panel.add(sep);
        frame.addPanel(panel);

        int newindex = 0;
        for (ASTName n : this.elements){
            n.convertToPHP(tab+2, frame, newindex);
            newindex++;
        }

        panel = new JPanel(new FlowLayout(FlowLayout.LEFT,1,1));
        panel.setBackground(new Color(54,57,63));
        
        builder = new StringBuilder();
        for (int i=0; i<tab+1;i++){
            builder.append("    ");
        }
        panel.add(new JLabel(builder.toString()));
        sep = new SeparatorLabel(")", this, frame);
        panel.add(sep);
        frame.addPanel(panel);
    }

    /* (non-Javadoc)
     * @see fr.iutfbleau.InspectorModel.ASTNode#setVisibilityToAll(boolean)
     */
    public void setVisibilityToAll(boolean visibility) {
        this.visibility = visibility;
        for (ASTName n : this.elements){
            n.setVisibilityToAll(visibility);
        }
        
    }

    public String printConsoleForValue(boolean endElement) {
        return null;
    }

}
