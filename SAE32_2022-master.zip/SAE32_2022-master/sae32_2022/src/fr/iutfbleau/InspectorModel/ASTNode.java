package fr.iutfbleau.InspectorModel;

/**
 * Interface qui représente un noeud de l'arbre de syntaxe abstraite
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import javax.swing.JPanel;
import fr.iutfbleau.InspectorView.*;

public interface ASTNode {

    /**
     * Méthode qui renvoit une chaine de caractère qui représente la valeur d'un nom, cette chaine de caractère a pour but d'etre affiché à la console
     * @param endElement boolean qui indique si c'est le dernier élément d'un objet ou d'un tableau
     * @return la valeur du noeud qui sera affichée à la console
     */
    public String printConsoleForValue(boolean endElement);

    /**
     * Méthode qui renvoit une chaine de caractère qui représente le noeud, cette chaine de caractère a pour but d'etre affiché à la console
     * @param tab le nombre d'indentation à effectuer 
     * @param endElement boolean qui indique si c'est le dernier élément d'un objet ou d'un tableau
     * @return le noeud qui sera affiché à la console
     */
    public String printConsole(int tab,boolean endElement);

    /**
     * Méthode qui permet de configurer le JPanel principal pour l'affichage graphique en JSON. Cette méthode est réservée aux noeuds qui représente la valeur d'un nom. 
     * @param tab le nombre d'indentation à effectuer
     * @param frame la fenetre principale
     * @param panel le JPanel du nom précédent la valeur actuelle
     * @param endElement boolean qui indique si c'est le dernier élément d'un objet ou d'un tableau
     */
    public void configJSONPanelForValue(int tab, InspectorFrame frame, JPanel panel, boolean endElement);

    /**
     * Méthode qui permet de configurer le JPanel principal pour l'affichage graphique en JSON. Cette méthode est réservée à tous types de noeud sauf les valeurs de nom ou valeurs de tableau
     * @param tab le nombre d'indentation à effectuer 
     * @param frame la fenetre principale 
     * @param endElement boolean qui indique si c'est le dernier élément d'un objet ou d'un tableau
     */
    public void configJSONPanel(int tab, InspectorFrame frame, boolean endElement);

    /**
     * Méthode qui permet de set la visiblité d'un noeud 
     * @param visibility la nouvelle visiblité du noeud
     */
    public void setVisibility(boolean visibility);

    /**
     * Méthode qui permet de set la visibilité d'un noeud et de tous ses enfants
     * @param visibility la nouvelle visibilité à set
     */
    public void setVisibilityToAll(boolean visibility);

    /**
     * Méthode qui permet de get la visibilité d'un noeud
     * @return
     */
    public boolean getVisibility();

    /**
     * Méthode qui permet de configurer le JPanel principal pour l'affichage graphique en PHP. Cette méthode est réservée à tous types de noeud sauf les valeurs de nom ou valeurs de tableau
     * @param tab le nombre d'indentation
     * @param frame la fenetre principale  
     * @param index l'index du noeud, car en php, tout est tableau et les tableaux sont comme des dictionnaires, il faut donc un index pour les noeuds qui n'ont pas de nom
     */
    public void convertToPHP(int tab, InspectorFrame frame, int index);

    /**
     * Méthode qui permet de configurer le JPanel principal pour l'affichage graphique en PHP. Cette méthode est réservée aux noeuds qui représente la valeur d'un nom. 
     * @param tab le nombre d'indentation
     * @param frame la fenetre principale 
     * @param panel le JPanel qui contient le nom de la valeur de ce noeud
     */
    public void convertToPHPForValue(int tab, InspectorFrame frame, JPanel panel);

}
