package fr.iutfbleau.InspectorControler;

/**
 * Classe qui représente le depli et le repli d'un tableau ou d'un objet
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.event.*;
import fr.iutfbleau.InspectorView.*;

public class FoldUnfoldElement implements MouseListener{

    /**
     * Attribut représentant le separateur auquel on va ajouter l'evenement
     */
    private SeparatorLabel label;

    /**
     * Constructeur de la classe FoldUnfoldElement
     * @param label le separateur auquel on va ajouter l'evenement
     */
    public FoldUnfoldElement(SeparatorLabel label){
        this.label = label;
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        // on change la visibilite du noeud par l'inverse de la visibilite actuelle
        this.label.getNoeud().setVisibility(!(this.label.getNoeud().getVisibility()));
        this.label.getFrame().refreshToJson();

    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
    
}
