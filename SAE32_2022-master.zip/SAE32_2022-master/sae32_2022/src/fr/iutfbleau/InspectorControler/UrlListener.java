package fr.iutfbleau.InspectorControler;

/**
 * Classe qui represente l'evenement lie a la barre de recherche
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.event.*;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import fr.iutfbleau.InspectorView.*;
import fr.iutfbleau.InspectorModel.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class UrlListener implements ActionListener, MouseListener, KeyListener{

    /**
     * Attribut qui represente la fenetre principale 
     */
    private InspectorFrame frame;
    /**
     * Attribut qui represente le nombre de click
     */
    private int nbClick;

    /**
     * Constructeur de la classe UrlListener
     * @param frame la fenetre principale
     */
    public UrlListener(InspectorFrame frame){
        this.frame = frame;
    }

    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource().equals(this.frame.getValider())){
            if((!this.frame.getChampsUrl().getText().equals("")) && (!this.frame.getChampsUrl().getText().equals("Veuillez donner l'url du contenu JSON à afficher"))){
                try {
                    if (nbClick == 0) {
                        frame.getJSONButton().setEnabled(false);
                    }
                    URL u = new URL(this.frame.getChampsUrl().getText());
                    try {
                        InputStream i = u.openStream();
                        ASTObject racine = new ASTObject();
                        ASTTree arbre = new ASTTree(racine);
                        arbre.parseAndFill(i);
                        racine.setVisibility(true);
                        this.frame.setRacine(racine);
                        this.frame.getConstraints().gridy++;
                        this.frame.getConstraints().weighty = 1.0;
                        this.frame.getPrincipal().add(new JLabel(), this.frame.getConstraints());
                        this.frame.getPHPButton().setEnabled(true);
                        this.frame.refreshToJson();
                    } 
                    catch (IOException e1) {
                        JOptionPane.showMessageDialog(this.frame, "le fichier que vous essayer d'ouvrir est introuvale ):");
                    }
                }
                catch (MalformedURLException e1) {
                    JOptionPane.showMessageDialog(this.frame, "Votre url est mal formé");
                }
            }
            else{
                JOptionPane.showMessageDialog(this.frame, "Veuillez entrer un lien");
            }
        }
    }

    /* (non-Javadoc)
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource().equals(this.frame.getChampsUrl())) {
            this.frame.getChampsUrl().setText("");
        }
    }

    /**
     * Methode permettant de modifier la valeur du nbClick
     * @param n int
     */
    public void setNbClick(int n) {
        this.nbClick =  n;
    }

    /**
     * Methode permettant de retourner le nombre de click
     * @return nombre de click
     */
    public int getNbClick() {
        return this.nbClick;
    }

    /* (non-Javadoc)
     * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
     */
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            if((!this.frame.getChampsUrl().getText().equals("")) && (!this.frame.getChampsUrl().getText().equals("Veuillez donner l'url du contenu JSON à afficher"))){
                try {
                    if (nbClick == 0) {
                        frame.getJSONButton().setEnabled(false);
                    }
                    URL u = new URL(this.frame.getChampsUrl().getText());
                    try {
                        InputStream i = u.openStream();
                        ASTObject racine = new ASTObject();
                        ASTTree arbre = new ASTTree(racine);
                        arbre.parseAndFill(i);
                        racine.setVisibility(true);
                        this.frame.setRacine(racine);
                        this.frame.getConstraints().gridy++;
                        this.frame.getConstraints().weighty = 1.0;
                        this.frame.getPrincipal().add(new JLabel(), this.frame.getConstraints());
                        this.frame.refreshToJson();
                        this.frame.getPHPButton().setEnabled(true);
                    } 
                    catch (IOException e1) {
                        JOptionPane.showMessageDialog(this.frame, "Le fichier que vous voulez ouvrir est introuvable");
                    }
                }
                catch (MalformedURLException e1) {
                    JOptionPane.showMessageDialog(this.frame, "Veuillez entrez un URL correcte");
                }
            }else{
                JOptionPane.showMessageDialog(this.frame, "Veuillez d'abord entrer un lien");
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}

    
}
