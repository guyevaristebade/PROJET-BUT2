package fr.iutfbleau.InspectorControler;

/**
 * Classe qui represente l'evenement permettant de passer du JSON au PHP et vice versa
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.JLabel;
import fr.iutfbleau.InspectorModel.*;
import fr.iutfbleau.InspectorView.*;

public class SwitchListener implements ActionListener{

    /**
     * Attribut qui represente la fenetre principale
     */
    private InspectorFrame frame;
    /**
     * Attribut qui represente le nombre de clicks
     */
    private int nbClick;
    /**
     *  Attribut qui represente l'evenement lie a la barre de recherche
     */
    private UrlListener ev;

    /**
     * Constructeur de la classe SwitchListener
     * @param f la fenetre principale
     */
    public SwitchListener(InspectorFrame f) {

        this.frame = f;
        this.ev = new UrlListener(frame);
    }

    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("JSON")) {
            this.ev.setNbClick(0);
            try {
                if (nbClick == 0) {
                    frame.getJSONButton().setEnabled(false);
                    frame.getPHPButton().setEnabled(true);
                    frame.getDeplier().setEnabled(true);
                    frame.getPlier().setEnabled(true);
                }
                URL u = new URL(this.frame.getChampsUrl().getText());
                try {
                    InputStream i = u.openStream();
                    ASTObject racine = new ASTObject();
                    ASTTree arbre = new ASTTree(racine);
                    arbre.parseAndFill(i);
                    racine.setVisibility(true);
                    this.frame.setRacine(racine);
                    this.frame.getConstraints().gridy++;
                    this.frame.getConstraints().weighty = 1.0;
                    this.frame.getPrincipal().add(new JLabel(), this.frame.getConstraints());
                    this.frame.refreshToJson();
                } 
                catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            catch (MalformedURLException e1) {
                e1.printStackTrace();
            }
            
        }

        if (e.getActionCommand().equals("PHP")) {

            this.ev.setNbClick(0);
            try {
                if (nbClick == 0) {
                    frame.getJSONButton().setEnabled(true);
                    frame.getPHPButton().setEnabled(false);
                    frame.getDeplier().setEnabled(false);
                    frame.getPlier().setEnabled(false);
                }
                URL u = new URL(this.frame.getChampsUrl().getText());
                try {
                    InputStream i = u.openStream();
    
                    ASTObject racine = new ASTObject();
                    ASTTree arbre = new ASTTree(racine);
                    arbre.parseAndFill(i);
                    racine.setVisibility(true);
                    
                    this.frame.setRacine(racine);
                    

                    this.frame.getConstraints().gridy++;
                    this.frame.getConstraints().weighty = 1.0;
                    this.frame.getPrincipal().add(new JLabel(), this.frame.getConstraints());
                    this.frame.refreshToPHP();
                } 
                catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            catch (MalformedURLException e1) {
                e1.printStackTrace();
            }
            
        }
        
    }
    
}
