package fr.iutfbleau.InspectorControler;

/**
 * Classe qui représente l'evenement de depli et repli de tous les objets et tableaux
 * 
 * @version 1.0
 * @author Faten Mars, Guy Bade, Hamza Chaaba
 */

import java.awt.event.*;
import fr.iutfbleau.InspectorView.*;

public class FoldUnfoldAll implements ActionListener{

    /**
     * Attribut représentant la fenetre principale
     */
    private InspectorFrame frame;

    /**
     * Constructeur de la classe FoldUnfoldAll
     * @param frame la fenetre principale 
     */
    public FoldUnfoldAll(InspectorFrame frame){
        this.frame = frame;
    }

    /* (non-Javadoc)
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // si on clique sur le bouton "Tout deplier" on deplie tous les objets et tableaux
        if (e.getActionCommand()=="Tout déplier"){
            this.frame.depliTout();
        }
        // si on clique sur le bouton "Tout replier" on replie tous les objets et tableaux 
        else if (e.getActionCommand()=="Tout plier"){
            this.frame.pliTout();
        }
    }

}
