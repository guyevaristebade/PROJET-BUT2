# SAE 3.2

Voici la SAE 3.2 du groupe dont les membres sont :

-Mars Faten

-Bade Guy

-Chaaba Hamza

Encadré par Luc Hernandez

-Pour générer la javadoc, vous devez exécuter la commande suivante :

make doc

-Pour compiler les fichiers sources, vous devez exécuter la commande suivante :

make compile

-Pour créer le fichier jar, vous devez exécuter la commande suivante :

make jar

-Pour supprimer les fichiers .class ainsi que le .jar, vous devez exécuter la commande suivante :

make clean

-Pour exécuter le .jar, vous pouvez double cliquer dessus ou exécuter la commande suivante :

java -jar Inspecteur_de_JSON.jar

Un diagramme de classe est mis à disposition, il vous permettra de mieux comprendre l'ensemble des classes.

Un rapport est aussi mis à disposition, il contient un récapitulatif des fonctionnalités ajoutées ainsi que l'explication de l'arbre de syntaxe abstraite ainsi que la structure du code.

